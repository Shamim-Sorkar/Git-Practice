package com.shamim.Spring_Boot_Web_Job_App;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWebJobAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWebJobAppApplication.class, args);
	}

}
